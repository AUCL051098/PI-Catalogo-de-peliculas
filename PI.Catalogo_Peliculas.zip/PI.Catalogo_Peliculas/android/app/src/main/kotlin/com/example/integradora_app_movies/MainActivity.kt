package com.example.integradora_app_movies

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
